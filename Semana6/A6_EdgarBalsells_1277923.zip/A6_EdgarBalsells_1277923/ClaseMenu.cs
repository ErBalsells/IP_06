﻿using System.Collections;

class ClaseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi prgograma, gestión de presupuesto");
        Console.WriteLine();
        Console.WriteLine("Seleccione un tipo de area de la empresa");
        Console.WriteLine("Menu Principal");
        Console.WriteLine("1. Dirección");
        Console.WriteLine("2. Finanzas");
        Console.WriteLine("3. Producción");
        Console.WriteLine("4. Control de calidad");
        string SeleccionMenu;
        SeleccionMenu = Console.ReadLine();

        switch (SeleccionMenu)
        {
            case "1":
                Console.WriteLine("Ud selecciono opcion:" + SeleccionMenu + " dirección");
                break;
            case "2":
                Console.WriteLine("Ud selecciono opcion:" + SeleccionMenu + " finanzas");
                break;
            case "3":
                Console.WriteLine("Ud selecciono opcion:" + SeleccionMenu + " producción");
                break;
            case "4":
                Console.WriteLine("Ud selecciono opcion:" + SeleccionMenu + " Control de calidad");
                break;
            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
                Console.ReadKey();


        }

        {


        }

    }


 }





﻿using System;
namespace Ejercicios
{
    class Program
    {
        static void Main(string[] args)
        {
            double Vf, V0, a, t;
            Console.WriteLine("Ingrese la velocidad final (Vf): ");
            Vf = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la velocidad inicial (V0): ");
            V0 = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la aceleración (a): ");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el tiempo (t): ");
            t = double.Parse(Console.ReadLine());
           
            if (Vf == 0 && V0 != 0 && a != 0 && t != 0)
            {
                Vf = V0 + a * t;
                Console.WriteLine("La velocidad final es: {0}", Vf);
            }
            else if (V0 == 0 && Vf != 0 && a != 0 && t != 0)
            {
                V0 = Vf - a * t;
                Console.WriteLine("La velocidad inicial es: {0}", V0);
            }
            else if (a == 0 && Vf != 0 && V0 != 0 && t != 0)
            {
                a = (Vf - V0) / t;
                Console.WriteLine("La aceleración es: {0}", a);
            }
            else if (t == 0 && Vf != 0 && V0 != 0 && a != 0)
            {
                t = (Vf - V0) / a;
                Console.WriteLine("El tiempo es: {0}", t);
            }
            else
            {
                Console.WriteLine("Error: debe ingresar 3 de las 4 variables.");
            }
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine("Ingrese una cantidad en quetzales:");
            double cantidad = double.Parse(Console.ReadLine());
            if (cantidad < 0 || cantidad > 999.99)
            {
                Console.WriteLine("Error: la cantidad debe estar entre 0 y 999.99.");
            }
            else
            {
                int billetes100 = (int)(cantidad / 100);
                cantidad = cantidad % 100;
                int billetes50 = (int)(cantidad / 50);
                cantidad = cantidad % 50;
                int billetes20 = (int)(cantidad / 20);
                cantidad = cantidad % 20;
                int billetes10 = (int)(cantidad / 10);
                cantidad = cantidad % 10;
                int billetes5 = (int)(cantidad / 5);
                cantidad = cantidad % 5;
                int monedas1 = (int)(cantidad / 1);
                cantidad = cantidad % 1;
                int monedas25 = (int)(cantidad / 0.25);
                cantidad = cantidad % 0.25;
                int monedas10 = (int)(cantidad / 0.1);
                cantidad = cantidad % 0.1;
                int monedas5 = (int)(cantidad / 0.05);
                cantidad = cantidad % 0.05;
                int monedas01 = (int)(cantidad / 0.01);
                Console.WriteLine("Billetes de 100: {0}", billetes100);
                Console.WriteLine("Billetes de 50: {0}", billetes50);
                Console.WriteLine("Billetes de 20: {0}", billetes20);
                Console.WriteLine("Billetes de 10: {0}", billetes10);
                Console.WriteLine("Billetes de 5: {0}", billetes5);
                Console.WriteLine("Monedas de 1: {0}", monedas1);
                Console.WriteLine("Monedas de 0.25: {0}", monedas25);
                Console.WriteLine("Monedas de 0.1: {0}", monedas10);
                Console.WriteLine("Monedas de 0.05: {0}", monedas5);
                Console.WriteLine("Monedas de 0.01: {0}", monedas1);
            }
        }
    }
}
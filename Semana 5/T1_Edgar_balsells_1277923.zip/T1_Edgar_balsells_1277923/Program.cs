﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, Sedad, sCarrera, sCarne;
        Console.WriteLine("Ingrese Nombre");
        sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese Edad");
        Sedad = Console.ReadLine();
        Console.WriteLine("Ingrese Carrera");
        sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese Carne");
        sCarne = Console.ReadLine();

        Console.WriteLine("Nombre:" + sNombre);
        Console.WriteLine("Edad: " + Sedad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carne: " + sCarne);

        Console.WriteLine("Soy " + sNombre + "tengo " + Sedad + "años y estuido la carrera de " + sCarrera + "mi numero de carne es " + sCarne);
        Console.ReadKey();
    }
        

}
﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su Nombre: ");
        String Nombre = Console.ReadLine();
        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy " + Nombre);
        /* COMENTARIOS */
        Console.WriteLine("Hola mundo ");
        Console.WriteLine("Soy " + Nombre);
        Console.ReadKey();
    } 
}
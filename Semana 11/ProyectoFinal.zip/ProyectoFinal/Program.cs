﻿using System;

class Program
{
    static void Main()
    {
        while (true)
        {
            int opcion;

            Console.Clear();
            Console.WriteLine("Menú Principal");
            Console.WriteLine("1. Proceso principal (servicio)");
            Console.WriteLine("2. Manual de usuario");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");
            Console.WriteLine("Seleccione una opción: ");
            opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Proceso principal (servicio)");
                    Console.WriteLine("Por favor, espere...");
                    // Aquí se ejecutaría el código del proceso principal
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("Manual de usuario");
                    Console.WriteLine("1. Ingresar datos.");
                    Console.WriteLine("2. Procesar y obtener resultados.");
                    Console.WriteLine("3. Salir.");
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("Créditos");
                    Console.WriteLine("Edgar Balsells 1277923 y Enrique Gomez 1281523].");
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("Saliendo del programa.");
                    Environment.Exit(0);
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }

            Console.WriteLine("Presione cualquier tecla para continuar.");
            Console.ReadKey();
        }
    }
}
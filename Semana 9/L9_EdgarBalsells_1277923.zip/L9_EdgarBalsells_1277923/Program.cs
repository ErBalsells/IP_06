﻿using System;
namespace Monedas
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaración de variables
            double cantidad1, cantidad2, cantidad3;
            string moneda1, moneda2, moneda3;
            // Ingreso de datos
            Console.WriteLine("Ingrese la cantidad No. 1:");
            while (!double.TryParse(Console.ReadLine(), out cantidad1))
            {
                Console.WriteLine("Por favor, ingrese un número válido:");
            }
            Console.WriteLine("USD o GTQ?");
            moneda1 = Console.ReadLine();
            Console.WriteLine("Ingrese la cantidad No. 2:");
            while (!double.TryParse(Console.ReadLine(), out cantidad2))
            {
                Console.WriteLine("Por favor, ingrese un número válido:");
            }
            Console.WriteLine("USD o GTQ?");
            moneda2 = Console.ReadLine();
            Console.WriteLine("Ingrese la cantidad No. 3:");
            while (!double.TryParse(Console.ReadLine(), out cantidad3))
            {
                Console.WriteLine("Por favor, ingrese un número válido:");
            }
            Console.WriteLine("USD o GTQ?");
            moneda3 = Console.ReadLine();
            // Conversión de dólares a quetzales
            if (moneda1 == "USD")
            {
                cantidad1 = cantidad1 * 7.83;
            }
            if (moneda2 == "USD")
            {
                cantidad2 = cantidad2 * 7.83;
            }
            if (moneda3 == "USD")
            {
                cantidad3 = cantidad3 * 7.83;
            }
            // Ordenamiento de los montos en quetzales
            double[] montos = { cantidad1, cantidad2, cantidad3 };
            Array.Sort(montos);
            // Impresión de los resultados
            Console.WriteLine("Resultado:");
            foreach (double monto in montos)
            {
                Console.WriteLine(monto + " GTQ");
            }
        }
    }
}
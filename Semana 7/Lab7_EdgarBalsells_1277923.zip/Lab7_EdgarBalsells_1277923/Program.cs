﻿using System;
using System.ComponentModel.Design;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1");

       
        Console.Write("Número Entero: ");
        string input = Console.ReadLine();

        if (int.TryParse(input, out int numero))
        {
            if (numero > 0)
            {
                Console.WriteLine("Resultado: Positivo");
            }
            else if (numero < 0)
            {
                Console.WriteLine("Resultado: Negativo");
            }
            else
            {
                Console.WriteLine("Resultado: Neutro");
            }
        }
        else
        {
            Console.WriteLine("Error: Ingrese un número entero válido.");
        }

        Console.ReadKey();
        Console.Clear();
        Console.WriteLine("Ejercicio 2");

      
        Console.Write("Número de día: ");
        input = Console.ReadLine();

        if (int.TryParse(input, out int dia))
        {
            if (dia >= 1 && dia <= 7)
            {
                string nombreDia = ObtenerNombreDia(dia);
                Console.WriteLine("DIA: " + nombreDia);
            }
            else
            {
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
            }
        }
        else
        {
            Console.WriteLine("Error: Ingrese un número entero válido.");
        }
    }

    static string ObtenerNombreDia(int numeroDia)
    {
        switch (numeroDia)
        {
            case 1:
                return "Lunes";
            case 2:
                return "Martes";
            case 3:
                return "Miércoles";
            case 4:
                return "Jueves";
            case 5:
                return "Viernes";
            case 6:
                return "Sábado";
            case 7:
                return "Domingo";
            default:
                return "Desconocido";


        }



    }
}
